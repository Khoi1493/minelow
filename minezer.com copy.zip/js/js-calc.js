let selected = false;
document.querySelector("#theamount").addEventListener("keyup", (e) => {

  if (!selected) {
    alert("Select plan first!");
    e.target.value = ""
    return;
  }

  calculate_result(e.target);

})

document.querySelector("#plan-btn-1").addEventListener("click", (e) => {
  selected = 1;
  calculate_result(document.querySelector("#theamount"))
})
document.querySelector("#plan-btn-2").addEventListener("click", (e) => {
  selected = 2;
  calculate_result(document.querySelector("#theamount"))
})
document.querySelector("#plan-btn-3").addEventListener("click", (e) => {
  selected = 3;
  calculate_result(document.querySelector("#theamount"))
})
document.querySelector("#plan-btn-4").addEventListener("click", (e) => {
  selected = 4;
  calculate_result(document.querySelector("#theamount"))
})
document.querySelector("#plan-btn-5").addEventListener("click", (e) => {
  selected = 5;
  calculate_result(document.querySelector("#theamount"))
})
document.querySelector("#plan-btn-6").addEventListener("click", (e) => {
  selected = 6;
  calculate_result(document.querySelector("#theamount"))
})
document.querySelector("#plan-btn-7").addEventListener("click", (e) => {
  selected = 7;
  calculate_result(document.querySelector("#theamount"))
})
document.querySelector("#plan-btn-8").addEventListener("click", (e) => {
  selected = 8;
  calculate_result(document.querySelector("#theamount"))
})



function set_results(hourly, daily, week, total) {
  document.querySelector("#cal-hourly").value = hourly + "";
  document.querySelector("#cal-daily").value = daily + "";
  document.querySelector("#cal-week").value = week + "";
  document.querySelector("#cal-total").value = total + "";
}

function calculate_result(e) {
  if (selected === 1) {
    let amount = e.value;
    if (amount >= 1 && amount <= 399) {
      let hourly = ((0.08 / 100) * amount).toFixed(4);
      let daily = (hourly *
        24).toFixed(4);
      let week = (daily * 7).toFixed(4);
      let total = (daily * 10).toFixed(4);
      set_results(hourly, daily, week, total + " For 10 days")
    } else if (amount >= 400 && amount <= 999) {
      let hourly = ((1.50 / 100) * amount).toFixed(4);
      let daily = (hourly * 24).toFixed(4);
      let week = (daily * 7).toFixed(4);
      let total = (daily *
        10).toFixed(4);
      set_results(hourly, daily, week, total + " For 10 days")
    } else if (amount >= 1000 && amount <= 1999) {
      let hourly = ((3.00 / 100) * amount).toFixed(4);
      let daily = (hourly * 24).toFixed(4);
      let week = (daily * 7).toFixed(4);
      let total = (daily *
        10).toFixed(4);
      set_results(hourly, daily, week, total + " For 10 days")
    } else if (amount >= 2000 && amount <= 10000) {
      let hourly = ((5 / 100) * amount).toFixed(4);
      let daily = (hourly * 24).toFixed(4);
      let week = (daily * 7).toFixed(4);
      let total = (daily *
        10).toFixed(4);
      set_results(hourly, daily, week, total + " For 10 days")
    } else {
      set_results("----", "----", "----", "----")
    }
  }
  if (selected === 2) {
    let
      amount = e.value;
    if (amount >= 5 && amount <= 399) {
      let hourly = ((4.38 / 100) * amount).toFixed(2);
      let daily = (hourly *
        24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (hourly * 24).toFixed(2);
      set_results(hourly, daily, week, total)
    } else if (amount >= 400 && amount <= 999) {
      let hourly = ((4.70 / 100) * amount).toFixed(2);
      let daily = (hourly * 24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (hourly *
        24).toFixed(2);
      set_results(hourly, daily, week, total)
    } else if (amount >= 1000 && amount <= 1999) {
      let hourly = ((5.30 / 100) * amount).toFixed(2);
      let daily = (hourly * 24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (hourly *
        24).toFixed(2);
      set_results(hourly, daily, week, total)
    } else if (amount >= 2000 && amount <= 10000) {
      let hourly = ((5.42 / 100) * amount).toFixed(2);
      let daily = (hourly * 24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (hourly *
        24).toFixed(2);
      set_results(hourly, daily, week, total)
    } else {
      set_results("-.------", "-.------", "-.------", "-.------")
    }
  }
  if (selected === 3) {
    let amount = e.value;
    if (amount >= 5 && amount <= 399) {
      let hourly = ((1.64 / 100) * amount).toFixed(2);
      let daily = (hourly *
        24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (hourly * 72).toFixed(2);
      set_results(hourly, daily, week, total)
    } else if (amount >= 400 && amount <= 999) {
      let hourly = ((2.30 / 100) * amount).toFixed(2);
      let daily = (hourly * 24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (hourly *
        72).toFixed(2);
      set_results(hourly, daily, week, total)
    } else if (amount >= 1000 && amount <= 1999) {
      let hourly = ((3.10 / 100) * amount).toFixed(2);
      let daily = (hourly * 24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (hourly *
        72).toFixed(2);
      set_results(hourly, daily, week, total)
    } else if (amount >= 2000 && amount <= 10000) {
      let hourly = ((3.48 / 100) * amount).toFixed(2);
      let daily = (hourly * 24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (hourly *
        72).toFixed(2);
      set_results(hourly, daily, week, total)
    } else {
      set_results("-.------", "-.------", "-.------", "-.------")
    }
  }
  if (selected === 4) {
    let amount = e.value;
    if (amount >= 5 && amount <= 399) {
      let hourly = ((1.13 / 100) * amount).toFixed(2);
      let daily = (hourly * 24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (daily * 5).toFixed(2);
      set_results(hourly, daily, week, total)
    } else if (amount >= 400 && amount <= 999) {
      let hourly = ((1.93 / 100) * amount).toFixed(2);
      let daily = (hourly * 24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (daily * 5).toFixed(2);
      set_results(hourly, daily, week, total)
    } else if (amount >= 1000 && amount <= 1999) {
      let hourly = ((3.12 / 100) * amount).toFixed(2);
      let daily = (hourly * 24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (daily * 5).toFixed(2);
      set_results(hourly, daily, week, total)
    } else if (amount >= 2000 && amount <= 10000) {
      let hourly = ((4.67 / 100) * amount).toFixed(2);
      let daily = (hourly * 24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (daily * 5).toFixed(2);
      set_results(hourly, daily, week, total)
    } else {
      set_results("-.------", "-.------", "-.------", "-.------")
    }
  }
  if (selected === 5) {
    let
      amount = e.value;
    if (amount >= 5 && amount <= 399) {
      let hourly = ((0.84 / 100) * amount).toFixed(2);
      let daily = (hourly * 24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (daily * 9).toFixed(2);
      set_results(hourly, daily, week, total)
    } else if (amount >= 400 && amount <= 999) {
      let hourly = ((1.63 / 100) * amount).toFixed(2);
      let daily = (hourly * 24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (daily * 9).toFixed(2);
      set_results(hourly, daily, week, total)
    } else if (amount >= 1000 && amount <= 1999) {
      let hourly = ((2.20 / 100) * amount).toFixed(2);
      let daily = (hourly * 24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (daily * 9).toFixed(2);
      set_results(hourly, daily, week, total)
    } else if (amount >= 2000 && amount <= 10000) {
      let hourly = ((4.17 / 100) * amount).toFixed(2);
      let daily = (hourly * 24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (daily * 9).toFixed(2);
      set_results(hourly, daily, week, total)
    } else {
      set_results("-.------", "-.------", "-.------", "-.------")
    }
  }
  if (selected === 6) {
    let
      amount = e.value;
    if (amount >= 5 && amount <= 399) {
      let hourly = ((0.85 / 100) * amount).toFixed(2);
      let daily = (hourly * 24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (daily * 12).toFixed(2);
      set_results(hourly, daily, week, total)
    } else if (amount >= 400 && amount <= 999) {
      let hourly = ((1.65 / 100) * amount).toFixed(2);
      let daily = (hourly * 24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (daily * 12).toFixed(2);
      set_results(hourly, daily, week, total)
    } else if (amount >= 1000 && amount <= 1999) {
      let hourly = ((3.13 / 100) * amount).toFixed(2);
      let daily = (hourly * 24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (daily * 12).toFixed(2);
      set_results(hourly, daily, week, total)
    } else if (amount >= 2000 && amount <= 10000) {
      let hourly = ((4.17 / 100) * amount).toFixed(2);
      let daily = (hourly * 24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (daily * 12).toFixed(2);
      set_results(hourly, daily, week, total)
    } else {
      set_results("-.------", "-.------", "-.------", "-.------")
    }
  }
  if (selected === 7) {
    let amount = e.value;
    if (amount >= 1000 && amount <= 5000) {
      let hourly = ((23.81 / 100) * amount).toFixed(2);
      let daily = (hourly * 24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (daily * 7).toFixed(2);
      set_results(hourly, daily, week, total)
    }  else {
      set_results("-.------", "-.------", "-.------", "-.------")
    }
  }
  if (selected === 8) {
    let amount = e.value;
    if (amount >= 2000 && amount <= 10000) {
      let hourly = ((33.34 / 100) * amount).toFixed(2);
      let daily = (hourly * 24).toFixed(2);
      let week = (daily * 7).toFixed(2);
      let total = (daily * 10).toFixed(2);
      set_results(hourly, daily, week, total)
    } else {
      set_results("-.------", "-.------", "-.------", "-.------")
    }
  }
}