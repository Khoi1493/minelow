$('.dropdown-radio').find('input').change(function() {
  var dropdown = $(this).closest('.dropdown');
  var radioname = $(this).attr('name');
  var checked = 'input[name=' + radioname + ']:checked';
  //update the text
  var checkedtext = $(checked).closest('.dropdown-radio').text();
  dropdown.find('button').text( checkedtext );
});